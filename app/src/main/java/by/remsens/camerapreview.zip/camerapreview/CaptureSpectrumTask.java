package com.example.camerapreview;
import java.io.File;

import com.ftdi.j2xx.D2xxManager;
import com.ftdi.j2xx.FT_Device;
import com.ftdi.j2xx.D2xxManager.D2xxException;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;

public class CaptureSpectrumTask extends AsyncTask<Void, Void, Void> {
	private Activity activity;
	private int devCount = 0;
	private Spectrum spectrum;	 	 
	public static D2xxManager ftD2xx= null; 
	private FT_Device ftDev = null; 
	private int ExposureTime;  
	private int SplitNumber=10;
	String FileName;
	
	 
	 CaptureSpectrumTask(Activity activity,int ExposureTime) {
		 try {
			ftD2xx = D2xxManager.getInstance(activity);
			
		} catch (D2xxException e) {
			e.printStackTrace();
		} 
		 devCount = ftD2xx.createDeviceInfoList(activity); 

		 this.activity = activity;
		 this.ExposureTime = ExposureTime;
			

			
			
	 }
	 
	private int exposureFind() {
		double tick = 256/41.78;
		
		DataPacket mDataPacket = null;
		
		int ExposureTime=1;
		int k =0;
		
		while(k<=20) {
			spectrum = new Spectrum();
			ftDev.write(new FtdiPacket(FtdiPacket.SET_EXP,(int) (ExposureTime  / tick)).getByteArray());
			new FtdiPacket(ftDev).readParam();			

			ftDev.write(new FtdiPacket(FtdiPacket.GET_SP,0).getByteArray());			
			mDataPacket = new DataPacket(ftDev);
			spectrum.addSpectrum(mDataPacket.getSpectrum());
			int MaxSignal = spectrum.getMaxSignal();
			if ((MaxSignal<=40000) && (MaxSignal>=5000)) break;
			else if (MaxSignal>40000) ExposureTime /=2;
			else if (MaxSignal<5000) ExposureTime *=2;
			if (ExposureTime<1) ExposureTime =1;
			Log.d("MaxSignal","k: "+k+" "+ExposureTime+" "+MaxSignal);
			 k++; 
		};
		
		return ExposureTime; 
		
	}
	 
	@Override
	protected Void doInBackground(Void... arg0) {
		if  (devCount== 1) {
		ftDev = ftD2xx.openByIndex(activity, 0);
		if (ftDev!=null) {
			if (ftDev.isOpen() == true ) { 

			ftDev.setBaudRate(1000000); 
			ftDev.setDataCharacteristics(D2xxManager.FT_DATA_BITS_8, 
			D2xxManager.FT_STOP_BITS_1, D2xxManager.FT_PARITY_NONE); 			
			ftDev.setFlowControl(D2xxManager.FT_FLOW_NONE, (byte) 0x0b, (byte) 
					0x0d); 		
			
						
			double tick = 256/41.78;
			
			int ExposureTime = 10;
			
			ftDev.write(new FtdiPacket(FtdiPacket.SET_EXP,(int) (ExposureTime *tick)).getByteArray());
			int ExpPacket = new FtdiPacket(ftDev).readParam();
			Log.d("Exposure",""+ExpPacket*tick/1000);
			
			
			
			DataPacket mDataPacket = null;
			spectrum = new Spectrum();
			
			
			
			for (int i  = 0 ; i < SplitNumber; i++ ) {
			
			ftDev.write(new FtdiPacket(FtdiPacket.GET_SP,0).getByteArray());			
			mDataPacket = new DataPacket(ftDev);
			spectrum.addSpectrum(mDataPacket.getSpectrum());
		//	spectrum = spectrum.addSpectrum(mDataPacket.getSpectrum());
			
			/*ftDev.write(new FtdiPacket(FtdiPacket.GET_SP,1).getByteArray());			
			mDataPacket = new DataPacket(ftDev);
			spectrum = spectrum.subSpectrum(mDataPacket.getSpectrum());*/
			}
	
			spectrum.devideOnValue(SplitNumber);
			FileName = getOutputSpectrumFile().getPath();
			spectrum.SaveToFIle(FileName);
			int MaxSignal = spectrum.getMaxSignal();
			Log.d("MaxSignal",ExposureTime+" "+MaxSignal);
																																										
			}
			ftDev.close();
		}
		}
		else {
			//Toast.makeText(activity, "Нет соединения со спектрометром!", Toast.LENGTH_LONG);
		}
		return null;
	}
	
	
	 @Override
	    protected void onPostExecute(Void result) {
	      super.onPostExecute(result);	
	      ((MainActivity)activity).setSpecFileName(FileName);
	      
	    //  ((MainActivity)activity).setSpectrum(spectrum.toArray());	      	 
	    }
	 
	    /** Create a File for saving an image or video */
	    private static File getOutputSpectrumFile(){
	        // To be safe, you should check that the SDCard is mounted
	        // using Environment.getExternalStorageState() before doing this.

	        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(
	                  Environment.DIRECTORY_PICTURES), "SpecApp");
	        
	        // This location works best if you want the created images to be shared
	        // between applications and persist after your app has been uninstalled.

	        // Create the storage directory if it does not exist
	        if (! mediaStorageDir.exists()){
	            if (! mediaStorageDir.mkdirs()){
	                Log.d("MyCameraApp", "failed to create directory");
	                return null;
	            }
	        }

	        // Create a media file name
	        String timeStamp = MainActivity.timeStamp;
	        File speFile;	     
	        speFile = new File(mediaStorageDir.getPath() + File.separator +
	            "SPE_"+ timeStamp + ".spe");	     
	        return speFile;
	    }

	

}
