package com.example.camerapreview;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import android.util.Log;

import com.ftdi.j2xx.FT_Device;

public class DataPacket {
	  ByteBuffer buffer = ByteBuffer.allocate((16+13+3+3648+16)*2);
	  
	  DataPacket(FT_Device ftDev) {
		  byte[] data = new byte[(16+13+3+3648+16)*2];
		  buffer.order(ByteOrder.LITTLE_ENDIAN);
		  int num_read = ftDev.read(data);
		
		  buffer.put(data);
		  
	  }
	  
	  DataPacket(byte[] array) {
		  buffer.put(array);
	  }
	  
public Spectrum getSpectrum() {		   
		  int[] spectrumArray = new int[3648];
		  for (int i = 0; i <3648; i++)
			  spectrumArray[i] = buffer.getShort((16+13+3)*2+i*2) & 0xffff;

		return new Spectrum(spectrumArray);
		  
	  }
	  
	  int size() {
		  return buffer.capacity();
	  }
}
