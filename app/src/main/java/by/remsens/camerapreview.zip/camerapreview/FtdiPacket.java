package com.example.camerapreview;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import android.util.Log;

import com.ftdi.j2xx.FT_Device;

public class FtdiPacket {
	   ByteBuffer buffer = ByteBuffer.allocate(8);	  
	   int CS;
	   final static byte  GET_ID = 1;
	   final static byte  SET_EXP = 2;
	   final static byte  GET_SP = 5;
	   
	   FtdiPacket(FT_Device ftDev) {
		   byte[] data = new byte[8];
		   buffer.order(ByteOrder.LITTLE_ENDIAN);
		   ftDev.read(data);
		   buffer.put(data);
	   }
	   
	   FtdiPacket(byte[] array) {
		   buffer.order(ByteOrder.LITTLE_ENDIAN);
		   buffer.put(array);
		   if (!checkCS()) Log.d("FtdiPacket","Error_CS");		  
	   }
	   	  
	   
	   FtdiPacket(byte cmd, int param) {
		   buffer.order(ByteOrder.LITTLE_ENDIAN);
		   buffer.put(0, (byte) 0xa5);		   		   		   
		   buffer.put(1,cmd);		   
		   buffer.putInt(2, param);
		   
		   setCS();
		   buffer.put(buffer.capacity()-1,(byte) 0x5a);
		   buffer.put(buffer.capacity()-2,(byte)CS);
	   }
	   
	   int readParam() {
		   return buffer.getInt(2);
	   }
	   
	   byte[] getByteArray() {
		   return buffer.array();
	   }
	   
	   void fromByteArray(byte[] array) {
		   buffer.put(array);
		   
	   }
	   
	   public static int unsignedToBytes(byte b) {
		    return b & 0xFF;
		  }
	   
	   void setCS() {
		   CS=0;
		   for (int i =1; i < 6; i++) {
			    CS += unsignedToBytes(buffer.get(i));
		   }
		   CS = 256-CS;		 
		 //  CS = 255;
	   }
	   
	   boolean checkCS()  {
		   int checkCS = 0;
		   for (int i =1; i < 7; i++) {
			   checkCS += unsignedToBytes(buffer.get(i));
		   }
		
		return CS==checkCS;
	   }
	   

}
