package com.example.camerapreview;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.Locale;


import com.example.camerapreview.R.id;


import android.hardware.Camera;
import android.hardware.Camera.PictureCallback;
import android.os.Bundle;
import android.os.Environment;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.util.Log;

import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnLayoutChangeListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

public class MainActivity extends Activity {

		public static final int MEDIA_TYPE_IMAGE = 1;
	  
	  private Camera mCamera;
	  private CameraPreview mPreview;
	   
	  private String PhotoFileName;
	  private String SpecFileName;
	  int[] SpectrumArray;
	  
	  ProgressDialog dialog;
	   
	  final int CAMERA_ID = 0;
	  final boolean FULL_SCREEN = true;
	  
	  public static String timeStamp;
	  
	  
	  @Override
		public boolean onCreateOptionsMenu(Menu menu) {	    
		    super.onCreateOptionsMenu(menu);


		
		    menu.add("Просмотреть")
		    .setIcon(R.drawable.trash)
	        
	     //   .setOnMenuItemClickListener(this)
	        .setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM  | MenuItem.SHOW_AS_ACTION_WITH_TEXT);
		    
		    menu.add("Снять")
	        .setIcon(R.drawable.checkmark_checkmark)
	    //    .setOnMenuItemClickListener(this)
	        .setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM  | MenuItem.SHOW_AS_ACTION_WITH_TEXT);
	        

		    
	    
		    return true;
		    
		}
	  

	  @Override
	  protected void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);	 	 
	    setContentView(R.layout.activity_main);
	  }  	  	  	  
	  
	  public void startProgressDialog() {
		  	dialog = new ProgressDialog(this);
		    dialog.setMessage("Съемка...");
		    dialog.setIndeterminate(true);
	
		    dialog.show();
	  }
	  
	  public void setFileName(String FileName) {
		  		PhotoFileName = FileName;
		  		viewPhoto();
	  }
	  
	  public void setSpecFileName(String FileName) {
		  SpecFileName = FileName;
		  viewPhoto();
	  }
	  
	  public void setSpectrum(int[] spectrumArray) {
		  		SpectrumArray = spectrumArray;
		  		viewPhoto();
	  }
	  
	  public void  viewPhoto() {
		  if (PhotoFileName!=null) Log.d("PhotoFileName",PhotoFileName);
		  if ((PhotoFileName!=null) && (SpecFileName!=null)) {
			  dialog.dismiss();
			  Intent intent = new Intent(this, ViewOneActivity.class);
			  Bundle b = new Bundle();
			  b.putString("PhotoFileName", PhotoFileName); //Your id
			  b.putString("SpectrumFileName", SpecFileName);
			//  b.putIntArray("SpectrumArray", SpectrumArray);
			  intent.putExtras(b); //Put your id to your next Intent
			  startActivityForResult(intent, 0);
			  //startActivity(intent);
		  }
	  }
	  
	    public static Camera getCameraInstance(){
	        Camera c = null;
	        try {
	            c = Camera.open(0); // attempt to get a Camera instance
	        }
	        catch (Exception e){
	            // Camera is not available (in use or does not exist)
	        }
	        return c; // returns null if camera is unavailable
	    }
	    
	  @Override
	    protected void onResume()
	    {
	    	super.onResume();
	    	setContentView(R.layout.activity_main);
	    	  // Create an instance of Camera
	        mCamera = getCameraInstance();
	               
	        // Create our Preview view and set it as the content of our activity.
	        mPreview = new CameraPreview(this, mCamera);
	        FrameLayout preview = (FrameLayout) findViewById(R.id.camera_preview);                
	        preview.addView(mPreview);
	        
	 
	        RelativeLayout relativeLayoutControls = (RelativeLayout) findViewById(R.id.controls_layout);
	        relativeLayoutControls.bringToFront();
	        
	        final MainActivity mainActivity = this;
	        
	        final PictureCallback mPicture = new PictureCallback() {

	            @Override
	            public void onPictureTaken(byte[] data, Camera camera) {
	            	
	                File pictureFile = getOutputMediaFile(MEDIA_TYPE_IMAGE);
	                if (pictureFile == null){
	                    Log.d("1", "Error creating media file, check storage permissions: ");
	                    return;
	                }

	                try {
	                    FileOutputStream fos = new FileOutputStream(pictureFile);
	                    fos.write(data);
	                    fos.close();
	                    
	                    mainActivity.setFileName(pictureFile.getAbsolutePath());
	                  //  mCamera.startPreview();
	                    
	                } catch (FileNotFoundException e) {
	                    Log.d("1", "File not found: " + e.getMessage());
	                } catch (IOException e) {
	                    Log.d("!", "Error accessing file: " + e.getMessage());
	                }
	            }
	        };
	        
	        Button captureButton = (Button) findViewById(id.button_log);
	        captureButton.setOnClickListener(
	            new View.OnClickListener() {
	                @Override
	                public void onClick(View v) {
	                  	PhotoFileName = null;
	                	SpectrumArray = null;
	                	SpecFileName = null;
	                	timeStamp = getTimeStamp();
	                	startProgressDialog();
	                    mCamera.takePicture(null, null, mPicture);
	            		new CaptureSpectrumTask(mainActivity,20).execute();
	                }
	            }
	        );
	        
	        Button viewButton = (Button) findViewById(id.button_view);
	        viewButton.setOnClickListener(
	            new View.OnClickListener() {
	                @Override
	                public void onClick(View v) {
	                	 Intent intent = new Intent(mainActivity, ViewAllActivity.class);
	                	 startActivity(intent);

	                }
	            }
	        );
	        
	     
	        
	    	
	    	 
	    }
	  
	  public void onWindowFocusChanged (boolean hasFocus){
		    super.onWindowFocusChanged(hasFocus);
		   
		    RelativeLayout relativeLayoutControls = (RelativeLayout) findViewById(R.id.controls_layout);
		    final int width = relativeLayoutControls.getWidth();
	        final int height = relativeLayoutControls.getHeight();
	        
	        final View left_face = this.findViewById(id.rect_left_face);
	        final View right_face = this.findViewById(id.rect_right_face);
	        final View top_face = this.findViewById(id.rect_top_face);
	        final View bottom_face = this.findViewById(id.rect_bottom_face);
	        
		
	
	       left_face.addOnLayoutChangeListener(new OnLayoutChangeListener() {
	        
				@Override
				public void onLayoutChange(View arg0, int arg1, int arg2,
						int arg3, int arg4, int arg5, int arg6, int arg7,
						int arg8) {
					  int start_left = width/2-40;
					  int start_top = height/2-40;
					  left_face.setLeft(start_left);
				      left_face.setTop(start_top);
				      left_face.setRight(start_left+4);
				      left_face.setBottom(start_top+80);
				      					// TODO Auto-generated method stub
					
				}} );
	       
	       right_face.addOnLayoutChangeListener(new OnLayoutChangeListener() {	        
				@Override
				public void onLayoutChange(View arg0, int arg1, int arg2,
						int arg3, int arg4, int arg5, int arg6, int arg7,
						int arg8) {
					  int start_left = width/2-40;
					  int start_top = height/2-40;
				      right_face.setLeft(start_left+80);
				      right_face.setTop(start_top);
				      right_face.setRight(start_left+80+4);
				      right_face.setBottom(start_top+80);
				      					// TODO Auto-generated method stub
					
				}} );
	       
	      top_face.addOnLayoutChangeListener(new OnLayoutChangeListener() {	        
				@Override
				public void onLayoutChange(View arg0, int arg1, int arg2,
						int arg3, int arg4, int arg5, int arg6, int arg7,
						int arg8) {
					  int start_left = width/2-40;
					  int start_top = height/2-40;
					  top_face.setLeft(start_left);
					  top_face.setTop(start_top);
					  top_face.setRight(start_left+80+4);
					  top_face.setBottom(start_top+4);
				      					// TODO Auto-generated method stub
					
				}} );

	       bottom_face.addOnLayoutChangeListener(new OnLayoutChangeListener() {	        
				@Override
				public void onLayoutChange(View arg0, int arg1, int arg2,
						int arg3, int arg4, int arg5, int arg6, int arg7,
						int arg8) {
					  int start_left = width/2-40;
					  int start_top = height/2-40;
					  bottom_face.setLeft(start_left);
					  bottom_face.setTop(start_top+80);
					  bottom_face.setRight(start_left+80);
					  bottom_face.setBottom(start_top+80+4);
				      					// TODO Auto-generated method stub
					
				}} );
	       

	        
	 /*       left_face.setLeft(1);
	        left_face.setTop(1);*/
	        
		 
		}

	    
	    @Override
	    protected void onPause()
	    {
	    	super.onPause();
	    	releaseCamera();
	    	
	    }
	    
	    private void releaseCamera(){
	        if (mCamera != null){
	            mCamera.release();        // release the camera for other applications
	            mCamera = null;
	        }
	    }
	    
	    
	    /** Create a file Uri for saving an image or video */
	/*    private static Uri getOutputMediaFileUri(int type){
	          return Uri.fromFile(getOutputMediaFile(type));
	    }*/
	    
	    private static String getTimeStamp() {
	    	 return new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());
	    }

	    /** Create a File for saving an image or video */
	    private static File getOutputMediaFile(int type){
	        // To be safe, you should check that the SDCard is mounted
	        // using Environment.getExternalStorageState() before doing this.

	        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(
	                  Environment.DIRECTORY_PICTURES), "SpecApp");
	        
	        // This location works best if you want the created images to be shared
	        // between applications and persist after your app has been uninstalled.

	        // Create the storage directory if it does not exist
	        if (! mediaStorageDir.exists()){
	            if (! mediaStorageDir.mkdirs()){
	                Log.d("MyCameraApp", "failed to create directory");
	                return null;
	            }
	        }

	        // Create a media file name
	      //  String timeStamp = getTimeStamp();
	        File mediaFile;
	        if (type == MEDIA_TYPE_IMAGE){
	            mediaFile = new File(mediaStorageDir.getPath() + File.separator +
	            "IMG_"+ timeStamp + ".jpg");	     
	        } else {
	            return null;
	        }

	        return mediaFile;
	    }


	}



